async function loadStudents() {
  const res = await fetch('/api/students');
  const students = await res.json();
  const table = document.getElementById('studentTable');
  table.innerHTML = '';

  students.forEach((s, i) => {
    table.innerHTML += `
      <tr>
        <td>${i + 1}</td>
        <td>${escapeHtml(s.name)}</td>
        <td>${escapeHtml(s.email)}</td>
        <td>${escapeHtml(s.course)}</td>
        <td><button class="delete" onclick="deleteStudent(${s.id})">Delete</button></td>
      </tr>`;
  });

  document.getElementById('studentCount').textContent = students.length;
  document.getElementById('courseCount').textContent = new Set(students.map(s => s.course)).size;
  document.getElementById('enrollmentCount').textContent = students.length;
}

document.getElementById('studentForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    course: document.getElementById('course').value
  };

  await fetch('/api/students', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });

  e.target.reset();
  loadStudents();
});

async function deleteStudent(id) {
  await fetch('/api/students/' + id, {method: 'DELETE'});
  loadStudents();
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[c]));
}

loadStudents();
