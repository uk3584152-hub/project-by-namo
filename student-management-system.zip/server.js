const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let students = [
  { id: 1, name: 'Ali Khan', email: 'ali@example.com', course: 'AWS Cloud' },
  { id: 2, name: 'Ahmed Khan', email: 'ahmed@example.com', course: 'Web Development' }
];

app.get('/api/students', (req, res) => res.json(students));

app.post('/api/students', (req, res) => {
  const { name, email, course } = req.body;
  if (!name || !email || !course) return res.status(400).json({error:'All fields are required'});
  const student = { id: Date.now(), name, email, course };
  students.push(student);
  res.status(201).json(student);
});

app.delete('/api/students/:id', (req, res) => {
  students = students.filter(s => s.id !== Number(req.params.id));
  res.json({success:true});
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
