STUDENT MANAGEMENT SYSTEM

Current setup:
Website -> Node.js/Express -> temporary in-memory data

Later AWS setup:
Website -> Node.js/Express on EC2 -> AWS RDS MySQL

RUN LOCALLY:
1. Install Node.js.
2. Open terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

IMPORTANT:
The current student data is temporary and resets when the server restarts.
The next stage will replace this temporary storage with MySQL/AWS RDS.
